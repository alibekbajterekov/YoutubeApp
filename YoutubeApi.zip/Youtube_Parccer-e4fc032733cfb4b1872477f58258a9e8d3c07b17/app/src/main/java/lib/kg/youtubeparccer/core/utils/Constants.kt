package lib.kg.youtubeparccer.core.utils

const val part = "snippet,contentDetails"
const val channelId = "UCWcUsw5EBULSF4Eul0DLULg"